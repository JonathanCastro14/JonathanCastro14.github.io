'''
AP CSP PERIOD 5

3.2.1 Project 

Jonathan Castro and Erick Torres

'''

import os.path
import matplotlib.pyplot as plt

#Gets the file
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'Sleep_hours_18.CSV')
datafile = open(filename, 'r')

#Initialize lists / aggregators
jobs = []
numbers = []

#Skips the first line of the file
next(datafile)

# Go through file row by row and store variables
for row in datafile:
    job_type,num_employed = row.split(',')
    jobs += [job_type]
    numbers += [num_employed]
# Close file   
datafile.close()

#Variables for elements of pie chart
labels = jobs
colors = ['red', 'blue', 'green', 'yellow', 'pink','orange']
quantities = numbers

#Plots pie chart
fig, ax = plt.subplots(1, 1)
ax.set_aspect(1) 
ax.pie(quantities, labels=labels, colors=colors, autopct='%.0f%%')
ax.set_title('Average Number of Hours of Sleeping for 18 Year Olds ')
fig.show() 